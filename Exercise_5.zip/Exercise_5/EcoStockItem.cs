﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_5
{
    class EcoStockItem : StockItem
    {
        string mark;

        public string Mark
        {
            get
            {
                return mark;
            }

            set
            {
                if (value == "Krav" || value == "EG")//ändra till små/stora
                    mark = value;
                else
                    throw new Exception("Wrong Value");
            }
        }
        public EcoStockItem(string name, int stockCount, string mark)
        {
            Name = name;
            StockCount = stockCount;
            Mark = mark;
      
        }
    }
}
