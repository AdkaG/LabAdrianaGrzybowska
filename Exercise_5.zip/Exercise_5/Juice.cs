﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_5
{
    class Juice : EcoStockItem
    {
        string type;

        public string Type
        {
            get
            {
                return type;
            }

            set
            {
                if (value == "apple" || value == "orange")
                    type = value;
                else
                    throw new Exception("Wrong value");
            }
        }
        //public Juice(string name, int stockCount, string mark, string type)
        //{
        //    Name = name;
        //    StockCount = stockCount;
        //    Mark = mark;
        //    Type = type;
        //}
    }
}
