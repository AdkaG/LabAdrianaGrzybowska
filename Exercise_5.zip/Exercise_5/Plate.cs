﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_5
{
    class Plate:StockItem
    {
        string type;
        public string Type
        {
            get
            {
                return type;
            }

            set
            {
                if (value == "flat" || value == "deep")
                    type = value;
                else
                    throw new Exception("Wrong value");
            }
        }
        public Plate(string name, int stockCount, string type)
        {
            Name = name;
            StockCount = stockCount;
            Type = type; ;

        }
    }
}
