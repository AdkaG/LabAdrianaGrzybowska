﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_5
{
    class Program
    {
        static void Main(string[] args)
        {
            EcoStockItem eco = new EcoStockItem("abc", 50, "Krav");
            MainMenu();

        }

        public static void MainMenu()
        {
            bool loop = true;
            while (true)
            {
                Console.WriteLine("***   MENU   ***");
                Console.WriteLine("[1] Create product");
                Console.WriteLine("[2] Inventory product");
                Console.WriteLine("[3] List products");
                Console.WriteLine("[4] Exit");
                int choise = int.Parse(Console.ReadLine());
                switch (choise)
                {
                    case 1:
                        //met 1
                        break;
                    case 2:
                        //met 2
                        break;
                    case 3:
                        //met 3
                        break;
                    case 4:
                        loop = false;
                        break;
                    default:
                        Console.WriteLine("Wrong value");
                        break;
                }
            }
            Console.ReadLine();
        }
    }
}
