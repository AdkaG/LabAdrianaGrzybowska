﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_5
{
    class StockItem
    {
        static int id;//++ när man skapar ny instans - static constr
        string name;
        int stockCount;

        public static int Id
        {
            get
            {
                return id;
            }

            private set
            {
                id = value;
            }
        }
        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }
        public int StockCount
        {
            get
            {
                return stockCount;
            }

            set
            {
                if (value >= 0)
                    stockCount = value;
            }
        }

        static StockItem()
        {
            id = 0;
        }
        public StockItem()
        {
            id++;
        }
        public StockItem(string name, int stockCount) : this()
        {
            Name = name;
            StockCount = stockCount;
        }

        public void CreateProduct()
        {
            Console.WriteLine("What kind of product do you want to create?");
            Console.WriteLine("[1] Juice");
            Console.WriteLine("[2] Plate");
            Console.WriteLine("[3] Go back");
            int choise = int.Parse(Console.ReadLine());
            switch (choise)
            {
                case 1:
                    Console.WriteLine("Enter name:");
                    string juiceName = Console.ReadLine();
                    Console.WriteLine("Enter count:");
                    int juiceCout = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter mark (Krav/EG):");
                    string juiceMark = Console.ReadLine();
                    Console.WriteLine("Enter type (apple/orange):");
                    string juiceType = Console.ReadLine();
                    Juice juice = new Juice(juiceName, juiceCout, juiceMark, juiceType);
                    break;
                case 2:
                    Console.WriteLine("Enter name:");
                    string plateName = Console.ReadLine();
                    Console.WriteLine("Enter count:");
                    int plateCount = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter type (flat/deep):");
                    string plateType = Console.ReadLine();
                    Plate plate = new Plate(plateName, plateCount, plateType);
                    break;
                case 3:
                    Program.MainMenu();
                    break;
            }
        }
    }
}
