﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_5
{
    class Stock
    {
        StockItem[] stockItem = new StockItem[StockItem.Id];

        public StockItem this[int index]
        {
            get
            {
                if (index > 0 && index < stockItem.Length)
                    return stockItem[index];
                else
                    throw new Exception("Wrong value");
            }
            set
            {
                if (index > 0 && index < stockItem.Length)
                    stockItem[index] = value;
                else
                    throw new Exception("Wrong value");
            }
        }
        public Stock(StockItem[] stockItem)
        {
            for (int i = 0; i < stockItem.Length; i++)
            {
                Console.WriteLine($"{ stockItem[i]}"); 
            }
            
        }

    }
}
